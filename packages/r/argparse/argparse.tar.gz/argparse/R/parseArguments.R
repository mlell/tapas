parseArguments <-
function(expectedArgumentText){
    return(parseCommandLine(parseExpectedArgs(expectedArgumentText)))
}
